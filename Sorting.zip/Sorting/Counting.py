import time
import sys


def counting_sort(arr):
    if len(arr) == 0:
        return arr

    # Find the maximum element in the array
    max_value = max(arr)

    # Create a counting array of size max_value+1 or len(arr)
    count = [0] * (max_value + 1 if max_value + 1 < len(arr) else len(arr))

    # Count the occurrences of each element in the array
    for num in arr:
        count[num] += 1

    # Generate the sorted array
    sorted_arr = []
    for i in range(len(count)):
        while count[i] > 0:
            sorted_arr.append(i)
            count[i] -= 1

    return sorted_arr


def get_memory_usage():
    # Memory usage in MB
    return round(sys.getsizeof([]) / (1024 * 1024), 2)


def main():
    # Get user input for the array elements
    arr = input("Enter the array elements separated by space: ").split()
    arr = [int(num) for num in arr]

    # Start the stopwatch
    start_time = time.time()

    # Perform counting sort
    sorted_arr = counting_sort(arr)

    # Stop the stopwatch
    end_time = time.time()
    elapsed_time = round(end_time - start_time, 4)

    # Print the sorted array and performance metrics
    print("Sorted Array:", sorted_arr)
    print("Elapsed Time:", elapsed_time, "seconds")
    print("Memory Usage:", get_memory_usage(), "MB")


if __name__ == "__main__":
    main()
